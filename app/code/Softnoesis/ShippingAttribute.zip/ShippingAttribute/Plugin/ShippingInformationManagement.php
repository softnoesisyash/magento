<?php

namespace Softnoesis\ShippingAttribute\Plugin;

use Magento\Quote\Api\CartRepositoryInterface;

class ShippingInformationManagement
{
    private $logger;

    public $cartRepository;

    public function __construct(
        \Magento\Quote\Model\QuoteRepository $quoteRepository,
        CartRepositoryInterface $cartRepository,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->logger = $logger;
        $this->cartRepository = $cartRepository;
    }
    /**
     * @param \Magento\Checkout\Model\ShippingInformationManagement $subject
     * @param $cartId
     * @param \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
     */
    public function beforeSaveAddressInformation( \Magento\Checkout\Model\ShippingInformationManagement $subject, $cartId,         \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation    
    )
    {
        $quote = $this->cartRepository->getActive($cartId); 

        $shippingAddress = $addressInformation->getShippingAddress();
        $shippingAddressExtensionAttributes = $shippingAddress->getExtensionAttributes()->getTypeOfAddress();

        $billingAddress = $addressInformation->getBillingAddress();
        $billingAddressExtensionAttributes = $billingAddress->getExtensionAttributes()->getTypeOfAddress();
        
        if ($shippingAddressExtensionAttributes == 'other') {
            $customField = $addressInformation->getShippingAddress()->getExtensionAttributes()->getOtherAddress();
            $shippingAddress->setTypeOfAddress($customField);
            $billingAddress->setTypeOfAddress($customField);
            $quote->setTypeOfAddress($customField);
        }
        else{
            $this->logger->info("i am the else loop");
            // $this->logger->info($billingAddressExtensionAttributes);
            $shippingAddress->setTypeOfAddress($shippingAddressExtensionAttributes);
            $billingAddress->setTypeOfAddress($billingAddressExtensionAttributes);
            $quote->setTypeOfAddress($shippingAddressExtensionAttributes);
        }


        // $billingAddress = $addressInformation->getBillingAddress()->getExtensionAttributes()->getBillingAddress();

        
        // $type_of_address = $addressInformation->getShippingAddress()->getExtensionAttributes()->getTypeOfAddress();

        // $other_address = $addressInformation->getShippingAddress()->getExtensionAttributes()->getOtherAddress();


        // if(!empty($deliveryNote)){
        // $this->logger->info("Type of Address field value below");
        // $this->logger->info(print_r($deliveryNote, true));
        // }

        // if($type_of_address == 'other'){
        // $this->logger->info("Other Address field value below");
        // $this->logger->info(print_r($other_address, true));
        // $quote->setTypeOfAddress($other_address);
        // // $billingAddress->setBillingAddress($other_address);
        // }
        // else{
        //     $this->logger->info("Type of Address field value below");
        //     $this->logger->info(print_r($type_of_address, true));
        //     $quote->setTypeOfAddress($type_of_address);
        //     // $billingAddress->setBillingAddress($other_address);
        // }


        // $quote->setTypeOfAddress($deliveryNote);
        $this->cartRepository->save($quote);
        return [$cartId, $addressInformation];
    }
}