<?php


namespace Softnoesis\ShippingAttribute\Plugin;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Checkout\Model\Session as CheckoutSession;



class BillingAddressManagement
{
    
    protected $logger;

    public $cartRepository;

    protected $resourceConnection;

    private $checkoutSession;

    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        CartRepositoryInterface $cartRepository,
        ResourceConnection $resourceConnection,
        CheckoutSession $checkoutSession
    ) {
        $this->logger = $logger;
        $this->cartRepository = $cartRepository;
        $this->resourceConnection = $resourceConnection;
        $this->checkoutSession = $checkoutSession;
    }

    public function getQouteId()
    {
        return (int)$this->checkoutSession->getQuote()->getId();
    }

    public function beforeAssign(
        \Magento\Quote\Model\BillingAddressManagement $subject,
        $cartId,
        \Magento\Quote\Api\Data\AddressInterface $address
    ) {
        $this->logger->info("Billing Address Field");

        // $billingAddress = $address->getExtensionAttributes()->getBillingAddress();
        // $this->logger->info($billingAddress);

        $quote = $this->cartRepository->getActive($cartId); 

        $billingAddress = $address->getExtensionAttributes();
        $billingAddressExtensionAttributes = $billingAddress->getBillingAddress();

        // $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();
        // $orderDatamodel = $objectManager->get('Magento\Sales\Model\Order')->getCollection()->getLastItem();
        // $lastorderId   =   $orderDatamodel->getId();
        // $orderId = $lastorderId + 1;
        // $this->logger->info("ORDER ID");
        
        // $quoteId = $this->getQouteId();
        // $this->logger->info($quoteId);

        // $connection = $this->resourceConnection->getConnection();

        // $sql_sales_order_address = "update quote_address set type_of_address='".$billingAddressExtensionAttributes."' where quote_id = '".$quoteId."' AND address_type ='billing'" ;
        // // $this->logger->info($sql_sales_order_address);
        
        // $connection->query($sql_sales_order_address); 

        // $this->logger->info($billingAddressExtensionAttributes);
        
        if ($billingAddressExtensionAttributes == 'other') {
            // $customField = $address->getBillingAddress()->getExtensionAttributes()->getOtherAddress();
            // $billingAddress->setTypeOfAddress($customField);
            // $quote->setTypeOfAddress($customField);
        }
        else{
            $this->logger->info("Else loop");
            $address->setTypeOfAddress($billingAddressExtensionAttributes);
            // $quote->setTypeOfAddress($billingAddressExtensionAttributes);
        }
        $this->cartRepository->save($quote);
        return [$cartId, $address];
    }
}