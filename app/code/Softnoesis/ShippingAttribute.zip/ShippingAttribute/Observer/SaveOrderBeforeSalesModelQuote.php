<?php

namespace Softnoesis\ShippingAttribute\Observer;

use Magento\Framework\DataObject\Copy;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Model\Quote;
use Magento\Sales\Model\Order;
use Magento\Framework\App\ResourceConnection;

class SaveOrderBeforeSalesModelQuote implements ObserverInterface
{
    public $objectCopyService;

    protected $logger;
    protected $resourceConnection;


    public function __construct(
        Copy $objectCopyService,
        \Psr\Log\LoggerInterface $logger,
        ResourceConnection $resourceConnection

    ) {
        $this->logger = $logger;
        $this->objectCopyService = $objectCopyService;
        $this->resourceConnection = $resourceConnection;
    }

    public function execute(Observer $observer)
    {
          $order = $observer->getEvent()->getData('order');

          /** @var \Magento\Sales\Model\Order $order */
        //   $order = $observer->getEvent()->getData('order');
        //   $order = $order->getData();
          /** @var \Magento\Quote\Model\Quote $quote */
          $quote = $observer->getEvent()->getData('quote');
          $shippingAddressData = $quote->getShippingAddress()->getData();
        $billingAddressData = $quote->getBillingAddress();

        //   $this->logger->info("this is the observer file");
        //   $this->logger->info($shippingAddressData['type_of_address']);
        //   die();

          if (isset($shippingAddressData['type_of_address'])) {

                $this->logger->info("Order ID");
                $this->logger->info($shippingAddressData['type_of_address']);
                $this->logger->info($billingAddressData->getTypeOfAddress());
                // $this->logger->info($order->getId());

                $order_id = $order->getId();
                $this->logger->info($order_id);

                $connection = $this->resourceConnection->getConnection();
                $type_of_address = $shippingAddressData['type_of_address'];

                $sql_sales_order_address = "update sales_order_address set type_of_address='".$type_of_address."' where parent_id = '".$order_id."'";
                $connection->query($sql_sales_order_address); 
              
                $sql_sales_order = "update sales_order set type_of_address='".$type_of_address."' where entity_id = '".$order_id."'";
                $connection->query($sql_sales_order);

              //$order->getShippingAddress()->setTypeofAddress($shippingAddressData['type_of_address']);

          }
  
        //   if (isset($billingAddressData['type_of_address'])) {
        //     $this->logger->info("this is the billing address condition");
        //     $this->logger->info($billingAddressData['type_of_address']);

        //     $order->getBillingAddress()->setTypeofAddress($billingAddressData['type_of_address']);


        //   }
        $this->objectCopyService->copyFieldsetToTarget(
            'sales_convert_quote',
            'to_order',
            $observer->getEvent()->getQuote(),
            $observer->getEvent()->getOrder()
        );

        // $this->objectCopyService->copyFieldsetToTarget(
        //     'sales_convert_quote_address',
        //     'to_order_address',
        //     $quote->getShippingAddress(),
        //     $order->getShippingAddress()
        // );


        // $this->objectCopyService->copyFieldsetToTarget('sales_convert_quote', 'to_order_address', $quote, $order);

        // $this->objectCopyService->copyFieldsetToTarget(
        //     'sales_convert_quote_address',
        //     'to_order_address',
        //     $observer->getEvent()->getQuote(),
        //     $observer->getEvent()->getOrder()
        // );

        return $this;
    }
}