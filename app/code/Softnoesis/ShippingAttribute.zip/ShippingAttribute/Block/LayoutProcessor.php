<?php

namespace Softnoesis\ShippingAttribute\Block;

class LayoutProcessor implements \Magento\Checkout\Block\Checkout\LayoutProcessorInterface
{
    public function process($jsLayout)
    {
        // Loop all payment methods (because billing address is appended to the payments)
        $configuration = $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']['payment']['children']['payments-list']['children'];
        foreach ($configuration as $paymentGroup => $groupConfig) {
            if (isset($groupConfig['component']) AND $groupConfig['component'] === 'Magento_Checkout/js/view/billing-address') {

                $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']['children']
                ['payment']['children']['payments-list']['children'][$paymentGroup]['children']['form-fields']['children']['custom_attribute_code'] = [
                    'component' => 'Magento_Ui/js/form/element/checkbox-set',
                    'config' => [
                        'customScope' => 'billingAddress.extension_attributes',
                        'template' => 'ui/form/field',
                        'elementTmpl' => 'ui/form/element/checkbox-set',
                    ],
                    'dataScope' => $groupConfig['dataScopePrefix'] . '.extension_attributes.' . 'billing_address',
                    'label' => __('Type of Address'),
                    'provider' => 'checkoutProvider',
                    'visible' => true,
                    'validation' => [
                        'required-entry' => true,
                        'min_text_length' => 0,
                    ],
                    'sortOrder' => 80,
                    'options' => [
                        [
                            'value' => 'home',
                            'label' => 'Home'
                        ],
                        [
                            'value' => 'office',
                            'label' => 'Office'
                        ],
                        [
                            'value' => 'other',
                            'label' => 'Other'
                        ],
                    ],
                ];
            }
            
        }


        $attributeCode = 'type_of_address';
        $fieldConfiguration = [
            'component' => 'Magento_Ui/js/form/element/checkbox-set',
            'config' => [
                'customScope' => 'shippingAddress.extension_attributes',
                'customEntry' => null,
                'template' => 'ui/form/field',
                'elementTmpl' => 'ui/form/element/checkbox-set'
            ],
            'dataScope' => 'shippingAddress.extension_attributes' . '.' . $attributeCode,
            'label' => 'Type of Address',
            'provider' => 'checkoutProvider',
            'sortOrder' => 80,
            'validation' => [
                'required-entry' => true
            ],
            'options' => [
            [
                'value' => 'home',
                'label' => 'Home'
            ],
            [
                'value' => 'office',
                'label' => 'Office'
            ],
            [
                'value' => 'other',
                'label' => 'Other'
            ],
        ],
            'filterBy' => null,
            'customEntry' => null,
            'visible' => true,
            'value' => 'home' 
        ];

        $customAttributeCode = 'other_address';
        $customField = [
            'component' => 'Magento_Ui/js/form/element/abstract',
            'config' => [
                // customScope is used to group elements within a single form (e.g. they can be validated separately)
                'customScope' => 'shippingAddress.extension_attributes',
                'customEntry' => null,
                'template' => 'ui/form/field',
                'elementTmpl' => 'ui/form/element/input',
            ],
            'dataScope' => 'shippingAddress.extension_attributes' . '.' . $customAttributeCode,
            'label' => 'Enter Address name',
            'provider' => 'checkoutProvider',
            'sortOrder' => 80,
            'id' => 'other_address',
            'options' => [],
            'filterBy' => null,
            'customEntry' => null,
            'visible' => false,
            'value' => '' // value field is used to set a default value of the attribute
        ];

        $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']['shippingAddress']['children']['shipping-address-fieldset']['children'][$customAttributeCode] = $customField;

        $jsLayout['components']['checkout']['children']
        ['steps']['children']['shipping-step']['children']
        ['shippingAddress']['children']['shipping-address-fieldset']
        ['children'][$attributeCode] = $fieldConfiguration;

        return $jsLayout;
    }
}
