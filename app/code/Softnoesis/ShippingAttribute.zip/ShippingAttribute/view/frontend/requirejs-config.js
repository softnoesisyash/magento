var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/set-billing-address': {
                'Softnoesis_ShippingAttribute/js/action/set-billing-address-mixin': true
            },
            'Magento_Checkout/js/action/place-order': {
                'Softnoesis_ShippingAttribute/js/action/set-billing-address-mixin': true
            },
            'Magento_Checkout/js/action/set-payment-information': {
                'Softnoesis_ShippingAttribute/js/action/set-billing-address-mixin': true
            },
            'Magento_Checkout/js/action/set-shipping-information': {
                'Softnoesis_ShippingAttribute/js/action/set-shipping-information-mixin': true
            }
        }
    }
};