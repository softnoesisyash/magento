require([
"jquery"
],function($){
     $( document ).ready(function() {

      //wait until the last element (.payment-method) being rendered
      // var existCondition = setInterval(function() {
      //  if ($('.price-excluding-tax').length) { 
      //   clearInterval(existCondition);
      //   runMyFunction();
      //  }
      // }, 1000);



      // function runMyFunction(){
      //   $(".admin__field-control div:eq(2) input").on('click', function(){
      //       alert("hello");
      //       });
      // }


      setTimeout(function(){

        // $(".admin__field-control div:eq(2) input").on('click', function(){
        //     console.log("clicked on other");
        //     $("#shipping-new-address-form > div:nth-child(6)").show();
        //     });

        // },3000);


    }); 
});