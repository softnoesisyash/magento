var config =
    {
        map:
        {
           '*':
               {
                'Magento_Catalog/js/catalog-add-to-cart': 'Softnoesis_Addtocartpopup/js/catalog-add-to-cart'
               }
        }
    };