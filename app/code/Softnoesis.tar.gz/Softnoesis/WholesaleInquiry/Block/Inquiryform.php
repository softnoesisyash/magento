<?php
namespace Softnoesis\WholesaleInquiry\Block;
class Inquiryform extends \Magento\Framework\View\Element\Template
{
}